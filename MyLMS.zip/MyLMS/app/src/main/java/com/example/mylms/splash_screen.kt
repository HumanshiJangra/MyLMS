package com.example.mylms

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView

class splash_screen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spalsh_screen)

        val image = findViewById<ImageView>(R.id.imageView2)
        val time : Long = 4000
        Handler().postDelayed(Runnable{
            val intent = Intent( this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, time)

    }
}